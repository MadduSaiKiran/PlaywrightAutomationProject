Project Agenda & Playwright Framework Features -

. Implement Page object Pattern for Web Automation tests.
. Create API Utilities for Data setup and clean up.
. How to drive test data from external files for Playwright tesțs.
. How to Parameterize the tests with different data sets in Playwright.
. Create Project Configurations with Playwright Config file.
. Test Retry feature in Playwright and how it works.
. How to record the video of test execution within Playwright framework.
. Understand how tests run in parallel mode in Playwright Framework.
. Test Annotations on run, skip, serial run & Parallel run.
. Playwright Command Line Arguments options to run tests.
. Detailed view of HTML Reporting with Trace viewer logs.
. Generating Allure reporting for Playwright execution results.
. How to create custom Scripts in package.json to trigger tests.
. Integrate the Playwright framework with Jenkins CI/CD Jobs and Schedule runs.